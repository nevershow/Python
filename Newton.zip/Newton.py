import random

# 使用数学公式计算出的概率值
# pA = 0.66510
# pB = 0.61867
# pC = 0.59734

def tossDices(diceNum):
   '''
      模拟抛骰子实验
      diceNum: 骰子的个数, 可为6,12,18
      least:   至少要有几个6
      sixTime: 抛diceNum个骰子出现6的次数
      返回值:  sixTime >= least则本次实验成功, 返回1, 否则返回0
   '''
   least = diceNum / 6
   sixTime = 0
   for dice in range(diceNum):
      if random.randint(1, 6) == 6:
         sixTime = sixTime + 1
         if sixTime == least:
            return 1
   return 0

def getProbability(tossTime, diceNum):
   '''
      计算某个命题成功的概率
      tossTime: 实验的总次数
      diceNum:  每次实验抛的骰子的个数
      count:    实验成功的次数
      返回值:   该命题的概率, 成功的次数count除以实验的总次数tossTime
   '''
   count = 0
   for toss in range(tossTime):
      count = count + tossDices(diceNum)
   return count * 1.0 / tossTime

def Newton(tossTime):
   '''
      输出三种命题对应成功的概率,精确到小数点后5位
      tossTime: 实验的总次数, 次数越多得到的概率越接近数学方法计算出来的概率
   '''
   print('\nA. Six fair dice are tossed independently and at least one "6" appears.\nThe probability of A is', end = ' ')
   print(round(getProbability(tossTime, 6), 5))

   print('\nB. Twelve fair dice are tossed independently and at least two "6" appears.\nThe probability of B is', end = ' ')
   print(round(getProbability(tossTime, 12), 5))

   print('\nC. Eighteen fair dice are tossed independently and at least three "6" appears.\nThe probability of C is', end = ' ')
   print(round(getProbability(tossTime, 18), 5))


Newton(1000000)  # 每个命题都进行100万次实验
